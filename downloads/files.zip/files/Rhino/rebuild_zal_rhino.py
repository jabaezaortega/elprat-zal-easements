# -*- coding: utf-8 -*-
"""RhinoPython (Rhino 7, IronPython 2.7) - rebuild the ZAL Port easement model from ../data/.
Run: Rhino > Tools > PythonScript > Run (or _RunPythonScript), pick this file. Model units must be Metres.
Creates layers Buildings::Buildings_now / Buildings_plus20 (coloured by clearance, user text with clearance values),
Critical_points, Envelope_ZAL_5m (mesh), Envelope_airport_150m (optional, vertex colours), ZAL_boundary.
Local coords: x=E-428000, y=N-4575000 (EPSG:25831), z = m AMSL (Alicante)."""
import json, os
import rhinoscriptsyntax as rs
import scriptcontext as sc
import Rhino.Geometry as rg
import System.Drawing as sd

HERE = os.path.dirname(os.path.abspath(__file__)) if '__file__' in dir() else rs.BrowseForFolder(message='Select the Rhino folder of the kit')
DATA = os.path.normpath(os.path.join(HERE, '..', 'data'))
ADD_AIRPORT = True

def ccol(c):
    if c < 0: return sd.Color.FromArgb(215, 25, 28)
    if c < 10: return sd.Color.FromArgb(253, 174, 97)
    if c < 20: return sd.Color.FromArgb(166, 217, 106)
    return sd.Color.FromArgb(26, 150, 65)

def layer(name, col):
    if not rs.IsLayer(name): rs.AddLayer(name, col)
    return name

def load(fn):
    with open(os.path.join(DATA, fn)) as f: return json.load(f)

def mesh_from(V, F, colors=None):
    m = rg.Mesh()
    for v in V: m.Vertices.Add(v[0], v[1], v[2])
    for f in F: m.Faces.AddFace(f[0], f[1], f[2])
    if colors:
        for c in colors: m.VertexColors.Add(c)
    m.Normals.ComputeNormals(); m.Compact()
    return m

rs.EnableRedraw(False)
for lay in ['Buildings', 'Critical_points']: layer(lay, sd.Color.Gray)
G = load('zal_buildings_local.geojson')
for f in G['features']:
    p = f['properties']; rings = f['geometry']['coordinates']
    for scn, dz in [('now', 0.0), ('plus20', 20.0)]:
        clr = p['clr_now'] if dz == 0 else p['clr_plus20']
        L = layer('Buildings::Buildings_' + scn, sd.Color.Gray)
        outer = rg.PolylineCurve([rg.Point3d(x, y, p['ground']) for x, y in rings[0]])
        if outer.ClosedCurveOrientation(rg.Vector3d.ZAxis) == rg.CurveOrientation.Clockwise: outer.Reverse()
        ex = rg.Extrusion.Create(outer, p['roof_med'] + dz - p['ground'], True)
        if ex is None: continue
        for h in rings[1:]: ex.AddInnerProfile(rg.PolylineCurve([rg.Point3d(x, y, p['ground']) for x, y in h]))
        gid = sc.doc.Objects.AddExtrusion(ex)
        rs.ObjectLayer(gid, L); rs.ObjectColor(gid, ccol(clr)); rs.ObjectName(gid, 'B%02d_%s_%s' % (p['bid'], p['localId'], scn))
        for k in ['localId', 'refcat', 'numberOfFloorsAboveGround', 'ground', 'roof_med', 'top_max', 'limit_amsl', 'gov_family', 'clr_now', 'clr_plus20', 'max_height_above_ground_allowed']:
            rs.SetUserText(gid, k, str(p[k]))
        rs.SetUserText(gid, 'scenario', scn); rs.SetUserText(gid, 'clearance_this_scenario', '%.2f' % clr)
        pid = rs.AddPoint(p['crit_x_local'], p['crit_y_local'], p['top_max'] + dz)
        rs.ObjectLayer(pid, layer('Critical_points::Critical_points_' + scn, sd.Color.Magenta)); rs.ObjectColor(pid, ccol(clr))
        rs.SetUserText(pid, 'clearance', '%.2f' % clr); rs.SetUserText(pid, 'limit_amsl', str(p['limit_amsl']))
E = load('zal_envelope_5m_local.json')
eid = sc.doc.Objects.AddMesh(mesh_from(E['vertices'], E['faces']))
rs.ObjectLayer(eid, layer('Envelope_ZAL_5m', sd.Color.FromArgb(74, 144, 217))); rs.ObjectName(eid, 'ZAL strictest envelope (m AMSL)')
if ADD_AIRPORT:
    A = load('airport_envelope_150m_local.json')
    hexc = lambda h: sd.Color.FromArgb(int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16))
    cols = [hexc(A['colors'][max(0, g)]) for g in A['vertex_group']]
    aid = sc.doc.Objects.AddMesh(mesh_from(A['vertices'], A['faces'], cols))
    rs.ObjectLayer(aid, layer('Envelope_airport_150m', sd.Color.Gray)); rs.ObjectName(aid, 'Airport strictest envelope 150 m')
Z = load('zal_boundary_local.geojson')['features'][0]['geometry']['coordinates'][0]
zid = rs.AddPolyline([(x, y, 5.0) for x, y in Z]); rs.ObjectLayer(zid, layer('ZAL_boundary', sd.Color.Magenta))
rs.LayerVisible('Buildings::Buildings_plus20', False); rs.LayerVisible('Critical_points::Critical_points_plus20', False)
rs.EnableRedraw(True); rs.ZoomExtents()
print('ZAL model rebuilt from %s' % DATA)
