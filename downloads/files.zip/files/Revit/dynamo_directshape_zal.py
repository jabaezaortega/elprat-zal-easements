# Dynamo for Revit 2024 (Dynamo 2.17+, Python Script node, engine CPython3)
# Creates DirectShapes (Generic Models) for the ZAL buildings and the easement envelope from the kit OBJ files,
# writes clearance values into instance parameters and colours the buildings by clearance in the ACTIVE VIEW.
# Inputs:  IN[0] = path to the kit 'data' folder (string)
#          IN[1] = scenario: 'now' or 'plus20' (string)
#          IN[2] = also import the envelope meshes? (bool)
# Geometry is in local metres: x=E-428000, y=N-4575000, z=m AMSL -> placed relative to the Revit INTERNAL ORIGIN.
# Set up shared coordinates so that the internal origin = E 428000 / N 4575000 / elevation 0 m AMSL (see README_Revit.md).
import clr, os, csv
clr.AddReference('RevitAPI'); clr.AddReference('RevitServices')
from Autodesk.Revit.DB import *
from RevitServices.Persistence import DocumentManager
from RevitServices.Transactions import TransactionManager

doc = DocumentManager.Instance.CurrentDBDocument
view = doc.ActiveView
data = IN[0]; scen = IN[1] if len(IN) > 1 and IN[1] else 'now'; with_env = IN[2] if len(IN) > 2 else True
FT = 1.0 / 0.3048

def read_obj(path):
    objs, verts, cur = [], [], None
    with open(path) as f:
        for ln in f:
            if ln.startswith('v '):
                _, x, y, z = ln.split(); verts.append(XYZ(float(x) * FT, float(y) * FT, float(z) * FT))
            elif ln.startswith('o ') or ln.startswith('g '):
                cur = [ln[2:].strip(), []]; objs.append(cur)
            elif ln.startswith('f '):
                if cur is None: cur = ['mesh', []]; objs.append(cur)
                cur[1].append([int(t.split('/')[0]) - 1 for t in ln.split()[1:4]])
    return objs, verts

def make_ds(name, faces, verts, cat=BuiltInCategory.OST_GenericModel):
    b = TessellatedShapeBuilder(); b.OpenConnectedFaceSet(False)
    for t in faces:
        try: b.AddFace(TessellatedFace([verts[t[0]], verts[t[1]], verts[t[2]]], ElementId.InvalidElementId))
        except Exception: pass
    b.CloseConnectedFaceSet(); b.Target = TessellatedShapeBuilderTarget.AnyGeometry; b.Fallback = TessellatedShapeBuilderFallback.Mesh
    b.Build(); res = b.GetBuildResult()
    ds = DirectShape.CreateElement(doc, ElementId(cat)); ds.SetShape(res.GetGeometricalObjects()); ds.Name = name
    return ds

def colour(c):
    if c < 0: return Color(215, 25, 28)
    if c < 10: return Color(253, 174, 97)
    if c < 20: return Color(166, 217, 106)
    return Color(26, 150, 65)

solid = [fp for fp in FilteredElementCollector(doc).OfClass(FillPatternElement) if fp.GetFillPattern().IsSolidFill][0]
rows = {r['localId']: r for r in csv.DictReader(open(os.path.join(data, 'zal_buildings_clearance.csv')))}
out = []
TransactionManager.Instance.EnsureInTransaction(doc)
objs, verts = read_obj(os.path.join(data, 'zal_buildings_%s_local.obj' % scen))
for name, faces in objs:
    lid = name.split('_', 1)[1].rsplit('_clr', 1)[0]; r = rows.get(lid, {})
    c = float(r.get('clr_plus20' if scen == 'plus20' else 'clr_now', 99))
    ds = make_ds('ZAL %s %s' % (scen, name), faces, verts)
    ds.get_Parameter(BuiltInParameter.ALL_MODEL_MARK).Set(lid)
    ds.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS).Set(
        'clearance %+.2f m | limit %s m AMSL | top %s m AMSL | %s | %s' % (c, r.get('limit_amsl'), r.get('top_max'), r.get('gov_family'), scen))
    ogs = OverrideGraphicSettings(); ogs.SetSurfaceForegroundPatternId(solid.Id); ogs.SetSurfaceForegroundPatternColor(colour(c))
    ogs.SetCutForegroundPatternId(solid.Id); ogs.SetCutForegroundPatternColor(colour(c))
    view.SetElementOverrides(ds.Id, ogs); out.append([name, c])
if with_env:
    for fn, nm, transp in [('zal_envelope_5m_local.obj', 'Envelope ZAL 5 m', 50), ('airport_envelope_150m_local.obj', 'Envelope airport 150 m', 60)]:
        eo, ev = read_obj(os.path.join(data, fn)); allf = [t for _, fs in eo for t in fs]
        ds = make_ds(nm, allf, ev)
        ds.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS).Set('Strictest RD 657/2022 envelope, m AMSL, AESA KMZ (no legal value)')
        ogs = OverrideGraphicSettings(); ogs.SetSurfaceTransparency(transp); ogs.SetSurfaceForegroundPatternId(solid.Id)
        ogs.SetSurfaceForegroundPatternColor(Color(74, 144, 217)); view.SetElementOverrides(ds.Id, ogs); out.append([nm, len(allf)])
TransactionManager.Instance.TransactionTaskDone()
OUT = out
