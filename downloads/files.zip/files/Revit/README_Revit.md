# ZAL Port vs LEBL easements in Revit 2024 (very short workflow)

**Files**
- `ZAL_buildings_now.ifc` and `ZAL_buildings_plus20.ifc` (IFC4). Each holds 64 buildings plus 42 "highest point" markers, as IfcBuildingElementProxy.
  - Buildings are footprints extruded from the LiDAR ground to the median roof.
  - Markers are 1×1 m posts that run up to the highest LiDAR point.
  - Property set `ZAL_Easement_Clearance`: Clearance_m, LimitHeight_AMSL_m, GoverningSurface, HighestPoint_AMSL_m, ClearanceClass, AboveLimit, and more.
- `LEBL_envelope_ZAL_and_airport.ifc` contains the strictest envelope as triangulated surfaces (IfcGeographicElement):
  - over ZAL on a 5 m grid
  - airport-wide on a 150 m grid
- `dynamo_directshape_zal.py` and `ZAL_DirectShape_clearance.dyn` (Dynamo 2.17, CPython3) create DirectShapes from `../data/*.obj` and colour them by clearance.
- `../data/` holds the CSV, GeoJSON and OBJ files, plus `ORIGIN_AND_UNITS.txt`.

**Coordinates.** All files use local metres:
- x = E − 428000, y = N − 4575000 (ETRS89 / UTM 31N)
- z = height above sea level (m AMSL, Alicante datum). z is not measured from the ground.

The IFCs also carry an IfcMapConversion (EPSG:25831, E 428000, N 4575000).

1. **Set up the project.** Create a project in metric metres and keep Project Base Point = Survey Point = Internal Origin.
   - Survey Point: Manage › Coordinates › Specify Coordinates at Point, picked at the internal origin. Enter N/S 4575000, E/W 428000, Elevation 0.
   - Set the view Elevation Base to "Survey Point" so levels read m AMSL.
   - Add levels at 0, 48 m (inner horizontal surface) and 59.1 m if useful.
2. **Link the IFCs.** Insert › Link IFC, positioned **Origin to Origin**. Link the three IFC files; buildings sit at their real height above sea level.
   - The IFC parameters show in Properties, and in schedules through the linked-model fields.
   - The parameter names can be mapped with Revit's IFC import options.
3. **Native geometry with clearance colours (optional).** Manage › Dynamo, open `ZAL_DirectShape_clearance.dyn`.
   - Set the data folder path and the scenario (`now` or `plus20`), then Run.
   - It creates Generic Model DirectShapes with Mark = Catastro id and Comments = clearance / limit / top / governing surface.
   - It overrides their colours in the active view: red < 0, orange 0–10, light green 10–20, green > 20 m.
   - The envelope meshes are imported as semi-transparent DirectShapes.
4. **View filters.** For colour coding without Dynamo, create rule-based filters on the Comments parameter: "contains clearance -" = red (above the limit).
   - Alternatively, schedule the CSV values onto a shared parameter "Clearance_m" and use filters < 0, < 10, < 20.
5. **Sections.** Draw a section along azimuth 59.5° through the ZAL Service Center critical point (local x ≈ −352.3, y ≈ −36.3). Add a perpendicular one as well.
   - The envelope surface cuts as a line at 48 m. Compare it with the building tops; this is the same as report Fig. 7.
6. **+20 m scenario.** Link `ZAL_buildings_plus20.ifc`, or run Dynamo with `plus20`. Toggle the links or worksets "now" and "+20 m".
   - Only B54 (the ZAL Service Center, 8352421DF2785C_6) goes over the limit: −9.19 m.

**Not tested here** (there is no Revit in the build environment):
- Revit linking of the IFCs
- running the Dynamo graph
- the .dyn file opening in Dynamo

The IFCs passed `ifcopenshell.validate` with 0 issues, and they were re-opened and their geometry tessellated. The .dyn is valid JSON with consistent node and port ids. Check the IFC import units are metres.

Prototype for visual checks only, no legal value. The AESA KMZ is informative only; RD 657/2022 and AESA's agreement prevail.
