# ZAL Port vs LEBL easements in Rhino 7 (very short workflow)

**Files**
- `ZAL_Port_easements.3dm`: Rhino 7 file, units metres, written and re-read with rhino3dm. Layers:
  - `Buildings::Buildings_now` and `Buildings::Buildings_plus20`: 64 extrusions each, coloured by clearance, with user text (clr_now, clr_plus20, limit_amsl, top_max, gov_family, and so on).
  - `Critical_points::*`: the highest LiDAR point of each building.
  - `Envelope_ZAL_5m`: mesh of the strictest envelope.
  - `Envelope_airport_150m`: mesh with vertex colours by governing surface.
  - `ZAL_boundary`.
- `rebuild_zal_rhino.py` rebuilds the same model from `../data` (RhinoPython, IronPython 2.7).
- `ghpython_clearance_component.py` is a GhPython component for live clearance in Grasshopper. No `.gh` file is included because a valid one can't be produced without Rhino.

**Coordinates**
- x = E − 428000, y = N − 4575000 (EPSG:25831)
- z = m AMSL (Alicante datum)
- To place the model at true UTM, move it by (428000, 4575000, 0), or set the location with `EarthAnchorPoint`.

1. **Open or import.** Open the .3dm, or run `_RunPythonScript rebuild_zal_rhino.py`. The OBJ files in `../data` can also be imported with `_Import`.
   - Use display mode Shaded or Arctic.
   - Turn `Buildings_plus20` on or off to switch scenarios.
2. **Colouring.** Objects use the object colour: red < 0, orange 0–10, light green 10–20, green > 20 m of clearance.
   - Select an object and open Properties › Attribute User Text to see its values.
   - To re-colour by another field, use `SelUserText` or the GhPython component.
3. **Clearance analysis.**
   - **Quick:** `_Distance`, or `_PointDeviation` between the `Critical_points` and the `Envelope_ZAL_5m` mesh.
   - **Visual:** `_Intersect` the buildings with the envelope mesh. Curves only appear where a building penetrates; in the +20 m scenario that is the Service Center tower.
   - **Grasshopper:**
     - Reference the buildings (B) and the envelope mesh (E), set dZ = 0 or 20, and use the GhPython script. It outputs clearance, critical point and colour per building, plus a summary.
     - Alternatives: `Mesh Ray`, or `Mesh Closest Point` between the roof sample points and the envelope.
     - Feed the colours into a Custom Preview.
4. **Sections.** `_Section` or `_ClippingPlane` along azimuth 59.5° through the critical point (−352.3, −36.3), plus a perpendicular one. Use a vertical scale factor (`_Scale1D` z × 3) for readability only.
5. **+20 m scenario.** Use the prepared `Buildings_plus20` layer, or `_Move` the buildings by +20 m in z, or set dZ = 20 in Grasshopper. Expect 1 building over the limit (−9.19 m).

**Validation done.**
- The .3dm re-opens with rhino3dm; archive version 70 (Rhino 7).
- Object counts: 128 extrusions, 128 points, 2 meshes, 1 curve.
- Z ranges were checked against the CSV.

**Not tested here** (no Rhino available): opening in Rhino 7 itself, and running the RhinoPython and GhPython scripts. Their syntax was checked only.
