"""GhPython component (Rhino 7 Grasshopper, IronPython 2.7) - live clearance of ZAL buildings against the envelope.
Inputs (set Type hints):  B  : Brep / Extrusion list (buildings, e.g. referenced from layer Buildings_now)  [List Access]
                          E  : Mesh (Envelope_ZAL_5m)                                                    [Item Access]
                          dZ : float, extra height added to every building (0 or 20)                     [Item Access]
                          step : float, sampling step on the roof in m (default 2)                       [Item Access]
Outputs: clr (min clearance per building, m), pt (critical point), col (colour per building),
         over (bool, penetrates), summary (text).
Method: sample a grid of points on each building's top face (+dZ), intersect a vertical ray with the envelope mesh,
clearance = envelope z - roof z. Uses the extruded (median) roof; for the LiDAR highest point use the Critical_points layer."""
import Rhino.Geometry as rg
import System.Drawing as sd
step = step or 2.0; dZ = dZ or 0.0
def ccol(c):
    return sd.Color.FromArgb(215,25,28) if c<0 else sd.Color.FromArgb(253,174,97) if c<10 else sd.Color.FromArgb(166,217,106) if c<20 else sd.Color.FromArgb(26,150,65)
clr, pt, col, over = [], [], [], []
for b in B:
    br = b.ToBrep() if hasattr(b,'ToBrep') else b
    bb = br.GetBoundingBox(True); ztop = bb.Max.Z + dZ
    best = (1e9, None); x = bb.Min.X
    while x <= bb.Max.X:
        y = bb.Min.Y
        while y <= bb.Max.Y:
            p = rg.Point3d(x, y, ztop)
            if br.IsPointInside(rg.Point3d(x, y, bb.Max.Z - 0.05), 0.01, False):
                t = rg.Intersect.Intersection.MeshRay(E, rg.Ray3d(rg.Point3d(x, y, -100), rg.Vector3d.ZAxis))
                if t >= 0:
                    c = (-100 + t) - ztop
                    if c < best[0]: best = (c, p)
            y += step
        x += step
    clr.append(best[0]); pt.append(best[1]); col.append(ccol(best[0])); over.append(best[0] < 0)
summary = '%d buildings, %d above the limit, min clearance %.2f m (dZ = %.0f m)' % (len(clr), sum(over), min(clr) if clr else 0, dZ)
