# ZAL Port vs LEBL easements: files for Rhino 7 and Revit 2024

| Folder | What it contains |
|---|---|
| `data/` | Shared data in local coordinates (see `ORIGIN_AND_UNITS.txt`): <br>• buildings with clearance attributes (CSV, GeoJSON, OBJ for now and +20 m) <br>• the strictest envelope over ZAL (5 m grid) and airport-wide (150 m grid), as OBJ and JSON <br>• the ZAL boundary |
| `data/GIS/` | GIS versions in EPSG:25831: GeoPackage/GeoJSON buildings, summary CSVs and rasters cropped to ZAL (envelope, clearance and governing surface; float32 GeoTIFF). They open in QGIS or ArcGIS. |
| `Rhino/` | `ZAL_Port_easements.3dm`, a RhinoPython rebuild script, a GhPython clearance component and `README_Rhino.md` |
| `Revit/` | IFC4 files (buildings now and +20 m with property sets; envelope surfaces), a Dynamo DirectShape script with its `.dyn` graph, and `README_Revit.md` |

**Coordinates**
- x = E − 428000, y = N − 4575000 (ETRS89 / UTM 31N)
- z = metres above sea level (Alicante datum), not above the ground
- Units: metres

Geometric prototype, with no legal value.
